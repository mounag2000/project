package backendBME.enums;

public enum EventRooms {
    Room_1,
    Room_2,
    Room_3,
    Room_4

}
