package backendBME.enums;

public enum EmployeeRole {
    ADMIN,
    USER
}
